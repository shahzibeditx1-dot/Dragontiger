package com.example.tigerdragon

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.min

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density

/** Glowing, rotating futuristic ring with a symbol in the centre. */
class RingView(ctx: Context) : View(ctx) {
    var color: Int = 0xFF00E5FF.toInt()
    var symbol: String = "?"
    var speed: Float = 2f // degrees per frame (60fps)

    private var angle = 0f
    private var last = 0L
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(4f)
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        isFakeBoldText = true
    }
    private val rect = RectF()

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    override fun onDetachedFromWindow() {
        last = 0L
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        if (last != 0L) {
            val frames = (now - last) / 16_666_667f
            angle = (angle + speed * frames) % 360f
        }
        last = now

        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - context.dp(8f)

        glowPaint.shader = RadialGradient(
            cx, cy, r * 1.4f,
            intArrayOf(withAlpha(color, 110), withAlpha(color, 0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.4f, glowPaint)

        ringPaint.color = color
        rect.set(cx - r, cy - r, cx + r, cy + r)
        for (i in 0 until 3) canvas.drawArc(rect, angle + i * 120f, 70f, false, ringPaint)

        ringPaint.color = withAlpha(color, 150)
        val r2 = r * 0.74f
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
        for (i in 0 until 2) canvas.drawArc(rect, -angle * 1.5f + i * 180f, 50f, false, ringPaint)

        textPaint.textSize = r * 0.8f
        canvas.drawText(symbol, cx, cy - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)

        postInvalidateOnAnimation()
    }
}

/** Thin neon progress bar. progress = 0f..1f */
class BarView(ctx: Context) : View(ctx) {
    var progress: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x3300E5FF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val w = width.toFloat()
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, h / 2, h / 2, track)
        if (progress > 0f) {
            rect.set(0f, 0f, w * progress, h)
            fill.shader = LinearGradient(
                0f, 0f, w, 0f,
                0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), Shader.TileMode.CLAMP
            )
            c.drawRoundRect(rect, h / 2, h / 2, fill)
        }
    }
}
