package com.example.tigerdragon

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

/** The small pop-up screen that opens when the floating icon is tapped. */
class PanelController(
    private val ctx: Context,
    private val onClose: () -> Unit,
    private val onStop: () -> Unit
) {
    private val cyan = 0xFF00E5FF.toInt()
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ring = RingView(ctx)
    private val status = label("READY", 18f, 0xFFFFFFFF.toInt())
    private val bar = BarView(ctx)
    private val button = label("CLICK", 14f, 0xFF001018.toInt())
    private var busy = false

    val root: LinearLayout = LinearLayout(ctx)

    init {
        val pad = ctx.dp(14f).toInt()
        root.apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(0xF0070D1A.toInt())
                cornerRadius = ctx.dp(22f)
                setStroke(ctx.dp(1.5f).toInt(), cyan)
            }
        }

        // Header
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            label("TIGER · DRAGON", 12f, cyan).apply { letterSpacing = 0.15f },
            LinearLayout.LayoutParams(0, wrap, 1f)
        )
        header.addView(iconButton("⏻", onStop))
        header.addView(iconButton("✕", onClose))
        root.addView(header, LinearLayout.LayoutParams(match, wrap))

        // Ring
        ring.symbol = "?"
        val ringSize = ctx.dp(150f).toInt()
        root.addView(ring, LinearLayout.LayoutParams(ringSize, ringSize))

        // Status text
        status.gravity = Gravity.CENTER
        status.letterSpacing = 0.1f
        root.addView(status, LinearLayout.LayoutParams(match, wrap))

        // Progress bar
        root.addView(bar, LinearLayout.LayoutParams(match, ctx.dp(6f).toInt()).apply {
            topMargin = ctx.dp(10f).toInt()
        })

        // Main button
        button.apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.25f
            val v = ctx.dp(12f).toInt()
            setPadding(v, v, v, v)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(cyan, 0xFF7C4DFF.toInt())
            ).apply { cornerRadius = ctx.dp(14f) }
            setOnClickListener { spin() }
        }
        root.addView(button, LinearLayout.LayoutParams(match, wrap).apply {
            topMargin = ctx.dp(12f).toInt()
        })

        // Honest note
        val note = label("Result 100% random hai", 10f, 0xFF6B7C8C.toInt()).apply {
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT
        }
        root.addView(note, LinearLayout.LayoutParams(match, wrap).apply {
            topMargin = ctx.dp(8f).toInt()
        })
    }

    private fun label(t: String, size: Float, c: Int) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(c)
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun iconButton(t: String, action: () -> Unit) =
        label(t, 16f, 0xFF8CA0B3.toInt()).apply {
            val p = ctx.dp(8f).toInt()
            setPadding(p, 0, p, 0)
            setOnClickListener { action() }
        }

    private fun spin() {
        if (busy) return
        busy = true
        val outcome = if (Random.nextBoolean()) "TIGER" else "DRAGON"

        status.text = "RANDOMIZING..."
        status.setTextColor(cyan)
        ring.color = cyan
        ring.speed = 14f
        button.alpha = 0.4f

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                bar.progress = f
                ring.symbol = if ((f * 18).toInt() % 2 == 0) "🐯" else "🐉"
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    finish(outcome)
                }
            })
            start()
        }
    }

    private fun finish(outcome: String) {
        val tiger = outcome == "TIGER"
        val c = if (tiger) 0xFFFFAB00.toInt() else 0xFF00E676.toInt()
        ring.symbol = if (tiger) "🐯" else "🐉"
        ring.color = c
        ring.speed = 2f
        status.text = if (tiger) "🐯 TIGER" else "🐉 DRAGON"
        status.setTextColor(c)

        ring.scaleX = 0.7f
        ring.scaleY = 0.7f
        ring.animate().scaleX(1f).scaleY(1f).setDuration(500)
            .setInterpolator(OvershootInterpolator(3f)).start()

        button.alpha = 1f
        busy = false
    }
}
