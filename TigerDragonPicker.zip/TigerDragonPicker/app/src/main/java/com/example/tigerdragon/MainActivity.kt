package com.example.tigerdragon

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = 0xFF050A14.toInt()
    private val cyan = 0xFF00E5FF.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = dp(24f).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(pad, pad, pad, pad)
        }

        val hero = RingView(this).apply { symbol = "TD" }
        val heroSize = dp(240f).toInt()
        root.addView(hero, LinearLayout.LayoutParams(heroSize, heroSize))

        root.addView(text("TIGER · DRAGON", 26f, cyan, bold = true).apply { letterSpacing = 0.15f })
        root.addView(text("RANDOM PICKER", 12f, 0xFF8CA0B3.toInt(), bold = true).apply {
            letterSpacing = 0.4f
        })

        val btn = text("OPEN PICKER", 16f, 0xFF001018.toInt(), bold = true).apply {
            letterSpacing = 0.25f
            val v = dp(16f).toInt()
            setPadding(v * 2, v, v * 2, v)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(cyan, 0xFF7C4DFF.toInt())
            ).apply { cornerRadius = dp(18f) }
            setOnClickListener { openPicker() }
        }
        root.addView(btn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(32f).toInt() })

        root.addView(
            text(
                "Pehli baar: Overlay permission ON karein, phir wapas aakar OPEN PICKER dabayein.\n" +
                        "Result sirf random hai — koi prediction nahi.",
                11f, 0xFF6B7C8C.toInt(), bold = false
            ).apply { setPadding(0, dp(20f).toInt(), 0, 0) }
        )

        setContentView(root)
    }

    private fun text(t: String, size: Float, c: Int, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(c)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun openPicker() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission ON karein, phir wapas aayein", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        moveTaskToBack(true)
    }
}
